package com.example.springmvc;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
@RestController
@Controller
public class FetchEmp {
   @GetMapping("emplist")
   ModelAndView show() {
	   ModelAndView mv=new ModelAndView();
	   
	   ArrayList<String> al=new ArrayList<>();
	   al.add("ramesh");
	   al.add("mahesh");
	   al.add("karan");
	   al.add("akash");
	   al.add("raj");
	   mv.setViewName("showemployee");
	   mv.addObject("data",al);
	  
	   
	   return mv;
	  
   }
   @GetMapping("getnumber")
   public int getnum()throws Exception {
	   System.out.println("in getnum");
	   int a=788;
	   System.out.println("value of a"+a);
	   return a;
   }
}
